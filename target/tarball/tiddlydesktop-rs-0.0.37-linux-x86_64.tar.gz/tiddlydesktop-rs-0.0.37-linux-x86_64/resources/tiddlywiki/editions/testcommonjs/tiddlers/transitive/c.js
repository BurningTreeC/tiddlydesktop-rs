/*\
title: transitive/c.js
type: application/javascript
module-type: library

Transitive test C

\*/


exports.foo = function () {
    return 1;
};

