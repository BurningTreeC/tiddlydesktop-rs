/*\
title: exactExports/a.js
type: application/javascript
module-type: library

ExactExports test A

\*/


exports.program = function () {
    return require('./program');
};


